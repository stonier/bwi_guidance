#begin_lua

loc_table={}
loc_table["cor"] = 0
loc_table["l3_414"] = 1
loc_table["l3_414a"] = 2
loc_table["l3_414b"] = 3
loc_table["s3_516"] = 4
door_table={}
door_table["d3_414a1"] = 0
door_table["d3_414a2"] = 1
door_table["d3_414b2"] = 2
door_table["d3_414b1"] = 3
door_table["d3_414b3"] = 4
door_table["d3_414a3"] = 5
door_table["d3_5161"] = 6
door_table["d3_5162"] = 7
function dis(a,b,c)
	d1 = door_table[tostring(a)]
	d2 = door_table[tostring(b)]
	if d1==d2 then return 1 end
	loc = loc_table[tostring(c)]
	if loc==0 then
		if d1==0 then
			if d2==1 then return 1 end
			if d2==2 then return 52 end
			if d2==3 then return 25 end
			if d2==6 then return 1 end
			if d2==7 then return 1 end
		end
		if d1==1 then
			if d2==0 then return 1 end
			if d2==2 then return 24 end
			if d2==3 then return 44 end
			if d2==6 then return 22 end
			if d2==7 then return 26 end
		end
		if d1==2 then
			if d2==0 then return 52 end
			if d2==1 then return 24 end
			if d2==3 then return 1 end
			if d2==6 then return 1 end
			if d2==7 then return 4 end
		end
		if d1==3 then
			if d2==0 then return 25 end
			if d2==1 then return 44 end
			if d2==2 then return 1 end
			if d2==6 then return 1 end
			if d2==7 then return 27 end
		end
		if d1==6 then
			if d2==0 then return 1 end
			if d2==1 then return 22 end
			if d2==2 then return 1 end
			if d2==3 then return 1 end
			if d2==7 then return 1 end
		end
		if d1==7 then
			if d2==0 then return 1 end
			if d2==1 then return 26 end
			if d2==2 then return 4 end
			if d2==3 then return 27 end
			if d2==6 then return 1 end
		end
	end
	if loc==1 then
		if d1==4 then
			if d2==5 then return 8 end
		end
		if d1==5 then
			if d2==4 then return 8 end
		end
	end
	if loc==2 then
		if d1==0 then
			if d2==1 then return 9 end
			if d2==5 then return 1 end
		end
		if d1==1 then
			if d2==0 then return 9 end
			if d2==5 then return 1 end
		end
		if d1==5 then
			if d2==0 then return 1 end
			if d2==1 then return 1 end
		end
	end
	if loc==3 then
		if d1==2 then
			if d2==3 then return 9 end
			if d2==4 then return 1 end
		end
		if d1==3 then
			if d2==2 then return 9 end
			if d2==4 then return 1 end
		end
		if d1==4 then
			if d2==2 then return 1 end
			if d2==3 then return 1 end
		end
	end
	if loc==4 then
		if d1==6 then
			if d2==7 then return 14 end
		end
		if d1==7 then
			if d2==6 then return 14 end
		end
	end
	return 1
end

#end_lua.
